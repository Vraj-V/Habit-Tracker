import { useState, useEffect, useCallback } from 'react';

export function useApi(url, options = {}) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      // Simulate API call with mock data
      await new Promise((resolve) => setTimeout(resolve, 500));

      // Mock data based on URL
      let mockData = {};
      if (url.includes('/habits')) {
        mockData = [
          { id: 1, name: 'Hydration', goal: '2.5L Daily', completion: 1.8, streak: 12 },
          { id: 2, name: 'Mindfulness', goal: '15 min Session', completion: 15, streak: 7 },
          { id: 3, name: 'Deep Reading', goal: '30 Pages Daily', completion: 25, streak: 5 },
        ];
      } else if (url.includes('/analytics')) {
        mockData = {
          sleepTimeline: '7h 12m',
          stressLevel: 'Low',
          exerciseStreak: 14,
        };
      } else if (url.includes('/community')) {
        mockData = {
          challenges: [
            { id: 1, name: '10k Steps Daily', participants: 4281, days: 3 },
            { id: 2, name: 'Morning Clarity', participants: 2100, days: 5 },
          ],
          leaderboard: [
            { rank: 1, name: 'Elena R.', points: 12040 },
            { rank: 2, name: 'David K.', points: 11850 },
            { rank: 3, name: 'Mia T.', points: 11200 },
          ],
        };
      }

      setData(mockData);
      setError(null);
    } catch (err) {
      setError(err.message);
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [url]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const refetch = useCallback(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch };
}
