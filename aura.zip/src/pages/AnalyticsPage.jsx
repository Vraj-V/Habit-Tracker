import { useState } from 'react';
import { useApi } from '../hooks/useApi';
import { TrendingUp, TrendingDown, Calendar } from 'lucide-react';

export default function AnalyticsPage() {
  const { data: analytics } = useApi('/api/analytics');
  const [timeRange, setTimeRange] = useState('month');

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Analytics</h1>
          <p className="text-muted">Deep insights into your health and habits</p>
        </div>
        <div className="flex gap-2">
          {['week', 'month', 'year'].map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition ${
                timeRange === range
                  ? 'bg-primary text-white'
                  : 'bg-surface border border-border text-muted hover:text-foreground'
              }`}
            >
              {range}
            </button>
          ))}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Sleep Timeline', value: analytics?.sleepTimeline || '7h 12m', change: '+5%', positive: true },
          { label: 'Stress Level', value: analytics?.stressLevel || 'Low', change: '-12%', positive: true },
          { label: 'Exercise Streak', value: analytics?.exerciseStreak || '14', unit: 'days', change: '+3', positive: true },
          { label: 'Completion Rate', value: '92', unit: '%', change: '+8%', positive: true },
        ].map((metric, i) => (
          <div key={i} className="bg-surface rounded-xl border border-border p-6">
            <p className="text-sm text-muted mb-3">{metric.label}</p>
            <div className="flex items-end gap-3">
              <div>
                <div className="text-2xl font-bold mb-1">{metric.value}</div>
                {metric.unit && <div className="text-xs text-muted">{metric.unit}</div>}
              </div>
              <div className={`flex items-center gap-1 text-sm ml-auto ${metric.positive ? 'text-accent' : 'text-error'}`}>
                {metric.positive ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                <span>{metric.change}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sleep Timeline */}
        <div className="bg-surface rounded-xl border border-border p-8">
          <h3 className="text-lg font-semibold mb-6">Sleep Timeline</h3>

          <div className="space-y-4 mb-6">
            {[
              { label: 'Deep', value: 2.5, color: '#4F46E5' },
              { label: 'Light', value: 3.2, color: '#7C3AED' },
              { label: 'REM', value: 1.5, color: '#10B981' },
              { label: 'Awake', value: 0.25, color: '#F59E0B' },
            ].map((sleep, i) => (
              <div key={i}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted">{sleep.label}</span>
                  <span className="text-sm font-semibold">{sleep.value}h</span>
                </div>
                <div className="w-full bg-surface-hover rounded-full h-2">
                  <div
                    className="rounded-full h-2"
                    style={{
                      backgroundColor: sleep.color,
                      width: `${(sleep.value / 7.4) * 100}%`,
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-sm text-muted">
            <p>Quality: 88% • Avg this week</p>
            <p className="mt-2">Best night was 3 days ago with 8h 15m sleep</p>
          </div>
        </div>

        {/* Stress Level */}
        <div className="bg-surface rounded-xl border border-border p-8">
          <h3 className="text-lg font-semibold mb-6">Stress Level</h3>

          <div className="relative h-48 flex items-center justify-center mb-6">
            <svg className="w-full h-full" viewBox="0 0 300 150">
              <polyline
                points="10,120 40,80 70,90 100,60 130,70 160,50 190,80 220,40 250,60 280,70"
                fill="none"
                stroke="#4F46E5"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <polyline
                points="10,120 40,80 70,90 100,60 130,70 160,50 190,80 220,40 250,60 280,70"
                fill="url(#gradient)"
                opacity="0.1"
              />
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#4F46E5" />
                  <stop offset="100%" stopColor="#4F46E5" stopOpacity="0" />
                </linearGradient>
              </defs>
            </svg>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center text-sm">
            <div>
              <p className="text-muted text-xs">Avg</p>
              <p className="font-semibold">45</p>
            </div>
            <div>
              <p className="text-muted text-xs">Low</p>
              <p className="font-semibold text-accent">28</p>
            </div>
            <div>
              <p className="text-muted text-xs">High</p>
              <p className="font-semibold text-error">72</p>
            </div>
          </div>
        </div>
      </div>

      {/* Exercise Streak */}
      <div className="bg-surface rounded-xl border border-border p-8">
        <h3 className="text-lg font-semibold mb-6">Exercise Streak</h3>

        <div className="mb-6">
          <div className="flex items-center gap-4 mb-6">
            <div>
              <div className="text-3xl font-bold">14</div>
              <div className="text-sm text-muted">Day Streak</div>
            </div>
            <div className="flex-1">
              <p className="text-sm text-muted mb-2">Total this month: 18 workouts</p>
              <div className="w-full bg-surface-hover rounded-full h-2">
                <div className="bg-accent rounded-full h-2" style={{ width: '70%' }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* Streak Calendar */}
        <div className="space-y-2">
          <p className="text-sm font-semibold mb-4">This Month</p>
          <div className="grid grid-cols-7 gap-2">
            {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day) => (
              <div key={day} className="text-center text-xs text-muted font-semibold mb-2">
                {day}
              </div>
            ))}
            {Array.from({ length: 31 }).map((_, i) => {
              const completed = Math.random() > 0.3;
              return (
                <div
                  key={i}
                  className={`aspect-square rounded-lg flex items-center justify-center text-xs font-semibold transition ${
                    completed ? 'bg-primary/20 text-primary' : 'bg-surface-hover text-muted'
                  }`}
                >
                  {i + 1}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Habit Performance */}
      <div className="bg-surface rounded-xl border border-border p-8">
        <h3 className="text-lg font-semibold mb-6">Habit Performance</h3>

        <div className="space-y-4">
          {[
            { name: 'Hydration', completion: 94, streak: 12 },
            { name: 'Morning Meditation', completion: 87, streak: 8 },
            { name: 'Exercise', completion: 76, streak: 14 },
            { name: 'Reading', completion: 65, streak: 5 },
          ].map((habit, i) => (
            <div key={i} className="flex items-center gap-4 p-4 bg-surface-hover rounded-lg">
              <div className="flex-1">
                <p className="font-semibold mb-2">{habit.name}</p>
                <div className="flex items-center gap-2 text-sm">
                  <div className="flex-1 bg-surface-darker rounded-full h-2">
                    <div className="bg-primary rounded-full h-2" style={{ width: `${habit.completion}%` }}></div>
                  </div>
                  <span className="text-muted text-xs">{habit.completion}%</span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-semibold">{habit.streak}</p>
                <p className="text-xs text-muted">day streak</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
